
 ----------------------------------------------------------------------
 KRYPTA 1.0 Encryption Tool Readme
 ----------------------------------------------------------------------
 
 Content

 1. Description
 2. Installation
 3. How To Use KRYPTA
 4. Security issues
 5. Technical Details
 6. Disclaimer

 ----------------------------------------------------------------------
 1. Description
 ----------------------------------------------------------------------


 KRYPTA is a basic tool to encrypt text to the clipboard or to decrypt
 the clipboard content to its text window. It is mainly designed to
 offer easy-to-use encryption to protect your e-mail communication.
 This small program provides a basic but strong encryption in a
 practical user-interface. KRYPTA is therefore a good alternative for
 people that are not familiar with cryptography or don't want to use
 complex encryption software. A description of the symmetric encryption
 algorithm is provided in this Readme and is easy to implement, even by
 novice programmers, thus making it easy to apply or adapt in different
 programming languages and on different platforms in various compatible
 software applications.

 ----------------------------------------------------------------------
 2. Installation
 ----------------------------------------------------------------------

 KRYPTA runs under Windows 98 or higer

 To install the full version that includes all required run-time files,
 open the zip file and select 'install' or extract the files to an
 empty folder and run setup.exe

 The KRYPTA program without run-time files can be extracted to any
 folder. If the required run-time files are not installed on the
 computer, you will need to install the full installation version.

 To uninstall:
 Open the configuration screen, choose software, select 'KRYPTA' in
 the list of programs and click the Add/Remove button.

 ----------------------------------------------------------------------
 3. How To Use KRYPTA
 ----------------------------------------------------------------------
 
 KRYPTA uses symmetric encryption. Encryption and decryption are
 performed with the same key. Therefore, the key must be shared by all
 parties that wish to exchange encrypted messages with each other.

 The clipboard is used as interface between KRYPTA and other software.
 Encrypting a message only requires few steps.

 Encryption:

 1. Enter your message text in the KRYPTA textbox
 2. Select the 'Encrypt' menu
    You will be prompted to enter a key, if not already entered
    The messages is encrypted and automatically sent to the clipboard
 3. Paste (ctrl+v) the clipboard content to any e-mail or text-editor
    program

 Decryption:

 1. Select and copy (ctrl+c) encrypted text from any program to the
    clipboard 
 2. Go to KRYPTA and select the 'Decrypt' menu
    You will be prompted to enter a key, if not already entered
    The decrypted text is displayed in the KRYPTA textbox

 When copying an encrypted message from another program to the
 clipboard, the program will automatically strip all unwanted heading
 and trailing characters and will only process hexadecimal characters
 (A-F and 0-9). Other characters, spaces and line breaks are
 disregarded.

 When a message is successfully encrypted to the clipboard, the KRYPTA
 textbox will be green. A successful decryption will turn the KRYPTA
 textbox red. The textbox will be white when text is edited.

 With the 'Key' menu you can enter a new key or change the current key.
 The 'Clear' menu will clear the textbox. Select the 'Word Wrap' menu
 to switch to automatic word wrapping.

 There is a Key cache of 2 minutes. After not using the program for
 more than 2 minutes the key and clipboard will be erased. After 10
 minutes of inactivity the textbox will also be erased, to protect the
 key and text if the program is left unattended.

 The clipboard is automatically cleared if the program is closed.

 When a new key is entered, the program will calculated the bit-
 strength of that key and give an indication of the key quality. An
 80 bit key strength is recommended by NIST, as this key size is
 generally accepted as impossible to brute-force with current and
 future technology. Too small or repetitive keys are refused by the
 program. Please read more about selecting good keys in the
 'Security Issues' section.

 ----------------------------------------------------------------------
 4. Security issues
 ----------------------------------------------------------------------

    a. Keywords and Passwords

 The security of KRYPTA depends entirely on the quality of the key. An
 indication to the bit-strength of the key is given by KRYPTA when the
 key is entered. However, this indication is not absolute, and doesn't
 check if the key isn't sensitive to for instance dictionary attacks.
 There are some basic tips for quality keys:

 Never use words, names, dates, abbreviations or other existing
 combinations! These are vulnerable to dictionary attacks. While a
 good key word has an infinity of combinations, a dictionary attack can
 reduce actual words to a few million or even thousands. Fast computers
 can process them in relative short time.

 Use a combination of small caps and capital letters, numbers and signs
 for key words. A five letter combination of only small caps letters
 gives you only 11,881,376 possible different combinations. If you use
 small and capital letters and numbers, there are already 916,132,832
 combinations. An eight character password has 2.18e+14 or 218 trillion
 possible combinations. Each additional character multiplies this with
 number with 62! Never use repetitions like '123123' or 'mamama'.

 Another way to compose your key is the use of a pass-phrase. Here we
 need other calculations. A normal language has an average vocabulary
 of about 5000 words. A pass-phrase with four words has 6.25e+14 or
 625 trillion possible combinations. This applies only on a phrase
 with random words, and no real sentences. If you use words in a logic
 order or a real sentence, the number of combination will be reduced.

    b. The Computer

 Every external connection on your computer is a security risk.
 There is always a possibility that others retrieve information from
 your computer through a network connection. This can be by remote
 control, Trojan horses or spyware, sending your files to others,
 capture keystrokes or screenshots. Therefore a stand-alone computer
 is recommended to store your crypto utilities. Even the most powerful
 encryption system is as strong as the most dangerous flaw in the
 security of your computer!

 ----------------------------------------------------------------------
 5. Technical Details
 ----------------------------------------------------------------------

 In this section you will find a complete description of KRYPTA. You
 can use this information to create your own software version of KRYPTA.
 Please make sure to write your code in such way that it is fully 
 compatible with KRYPTA. The name KRYPTA should only be used if the
 program is fully compatible.

 KRYPTA uses a symmetric encryption algorithm with variable length key
 with Initialisation Vector and is based on ARCFOUR, but features
 several improvements to provide better security against cryptanalysis.
 The original ARCFOUR (the alleged RC4) had some important
 disadvantages. The Fluhrer-Mantin-Shamir attack, which found biases
 in the first few generated bytes, and more recently the Tews-Pychkine-
 Weinmann attack showed that 80,000 WEP packets, using the same key and
 48 bit IV, could be sufficient to retrieve the key.

 The algorithm as applied in KRYPTA uses a 256 bit (32 byte)
 Initialisation Vector, appended to the key, to ensure a unique
 encryption, even with identical key and plaintext. The key
 initialisation loop is repeated 24 times to ensure a good mixing of
 the array bytes. In order to drop the key related bytes, the first
 3072 generated bytes are disregarded. Also, a cipher-feedback mode
 is implemented and each encrypted byte will therefore influence the
 next permutation of the array bytes, making a single decryption error
 fatal to the rest of the ciphertext. Thanks to these improvements
 the algorithm provides a fast, reliable and strong encryption.
 Although the messages volume, as used with KRYPTA, is too small for
 successful cryptanalysis and recovery of the key, it is recommended
 to regularly (>2Gb) change the encryption key.

 The encryption output is composed of the 32 IV bytes, followed by the
 encrypted text. In order to keep the source code compact and easy to
 apply for other programmers, the uncompressed output bytes are
 converted into hex values, which are accepted by any text editor or
 email program. The program disregard any character in the ciphertext,
 other hex values (A-F, 0-9)

 When designing your own program with this algorithm you will need to
 make sure that the user can only enter good non-repetitive keys with
 sufficient bit strength. In KRYPTA the following formula was used
 to calculate the bit strength and give a key quality indication:

 Bit strength = log(C^L)/log(2)

 Where C is the character variation and L the length of the key. If for
 example a key is composed of upper and lower case letters only, then
 C=52, and if it contains also digits C=62. Including also spaces and
 signs will raise CV to 88.

 Below are given the VB Source code snippets with the core elements of
 KRYPTA. These will help programmers to write their own compatible
 version.

 >>> module vars <<<

 Private s(255) As Integer
 Private P1     As Integer
 Private P2     As Integer

 >>> key initialisation <<<

 Don't forget to append a random IV of 32 bytes at the end of the key
 before initialising the key. Once the data is encrypted, the (not
 encrypted!) IV must be added at the beginning of the ciphertext. The
 random IV doesn't have to be crypto secure random, just good random.
 To decrypt, read in and append the IV to the key first, and then
 decrypt the rest of the message.


 For i = 0 To 255
     s(i) = i
 Next
 'transpose s-array 24 times with key
 For k = 1 To 24
     For i = 0 To 255
         j = (j + s(i) + key(i Mod KeyLen)) Mod 256
         tmp = s(i)
         s(i) = s(j)
         s(j) = tmp
     Next
 Next

 >>> Encryption Loop <<<

 CFB = 0
 'dump first 3072
 For k = 1 To 3072
     dummy = KRYPTA(CFB)
 Next
 'encryption loop
 For k = 0 To Ubound(text)
     i = text(k) Xor KRYPTA(CFB)
     text(k) = i
     CFB = i
 Next

 >>> Decryption loop <<<

 'decode cycle
 CFB = 0
 'dump first 3072
 For k = 1 To 3072
     dummy = KRYPTA(CFB)
 Next
 'decryption loop
 For k = 0 To Ubound(text)
     i = text(k)
     text(k) = i Xor KRYPTA(CFB)
     CFB = i
 Next

 >>> KRYPTA function <<<

 Private Function KRYPTA(feedback As Byte) As Byte
 Dim tmp As byte
 P1 = (P1 + 1) Mod 256
 P2 = (P2 + s(P1) + feedback) Mod 256
 tmp = s(P1)
 s(P1) = s(P2)
 s(P2) = tmp
 Tcrypt = s((s(P1) + s(P2)) Mod 256)
 End Function


 >>> Test Vectors <<<

 When you perform these tests, make sure that your code will only
 read the ciphertext hex chars (A-F,0-9) and no other letters, line
 feeds or signs. The program should accept both upper case and lower
 case version of the hex values.

 The first test should always produce the same output. Make sure to 
 use the fixed IV (only for test purposes!). This test can be used to
 verify both encryption and decryption.

 Key: ABCDabcd1234
 Text: The Quick Brown Fox Jumps Over The Lazy Dog
 Non random test IV: 32 x &H80 (ASCII value 128)
 Result:
 80808080808080808080808080808080808080808080808080808080808080805e8f
 c06a33d4b4d54e9de4c6d0a623159e0659eba027bdf4d51a576a44b70eb6a6edb333
 156ffdc4b04698

 Output is 32 x &h80 (IV) followed by the 43 hex values of the
 encrypted text.

 The second test uses a random IV. Do not use this test to verify the
 encryption result, since the IV, and therefore also the output, will
 always differ. Use it to verify the decryption output only.

 Key : ABCDabcd1234
 Ciphertext (with random IV):
 017d27405fb2d77dfb1e119896cfb9af5f88954366665ff753c31995585ba1520217
 e772a8915c884333ee7e1900b77a6ea55a476d41bb5a2f753baa5752cf5ebbf7d73a
 26f8866174d41e
 Result: The Quick Brown Fox Jumps Over The Lazy Dog


 ----------------------------------------------------------------------
 6. Disclaimer
 ----------------------------------------------------------------------

 THIS PROGRAM IS FREEWARE AND CAN BE USED AND DISTRIBUTED UNDER THE
 FOLLOWING RESTRICTIONS: IT IS STRICTLY FORBIDDEN TO USE THIS SOFTWARE
 OR COPIES OR PARTS OF IT FOR COMMERCIAL PURPOSES, OR TO SELL, TO LEASE
 OR TO MAKE PROFIT FROM THIS PROGRAM BY ANY MEANS. THIS SOFTWARE MAY
 ONLY BE USED IF YOU AGREE TO THESE CONDITIONS.

 THE NAME KRYPTA MAY ONLY BE USED IN OTHER SOFTWARE IF THAT SOFTWARE
 IS FULLY COMPATIBLE WITH THE ORIGINAL KRYPTA SOFTWARE. PLEASE CHECK
 THE TECHNICAL DETAILS FOR COMPATIBILITY INFORMATION.

   IMPORTANT NOTICE

 ABOUT RESTRICTIONS ON IMPORTING STRONG ENCRYPTION ALGORITHMS:

 THE KRYPTA ENCRYPTION ALGORITHM USES A LENGTH-VARIABLE KEY. IN SOME
 COUNTRIES IMPORT OF THIS TYPE OF SOFTWARE IS FORBIDDEN BY LAW OR HAS
 LEGAL RESTRICTIONS. CHECK FOR LEGAL RESTRICTIONS ON THIS SUBJECT IN
 YOUR COUNTRY.

   DISCLAIMER OF WARRANTIES
 
 THIS SOFTWARE AND THE ACCOMPANYING FILES ARE SUPPLIED "AS IS" AND
 WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESSED OR IMPLIED, WITH
 RESPECT TO THIS PRODUCT, ITS QUALITY, PERFORMANCE, MERCHANTABILITY,
 OR FITNESS FOR ANY PARTICULAR PURPOSE. THE ENTIRE RISK AS TO IT'S
 QUALITY AND PERFORMANCE IS WITH THE USER. IN NO EVENT WILL THE AUTHOR
 BE LIABLE FOR ANY DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES RESULTING
 OUT OF THE USE OF OR INABILITY TO USE THIS PRODUCT.

 ----------------------------------------------------------------------
 � D. Rijmenants 2008
 DR.Defcom@telenet.be
 http://users.telenet.be/d.rijmenants
 ----------------------------------------------------------------------

