
December 15, 2012

Closed Captions Update v1.0 by Dadster

Greetings to all Black Mesa (BM) lovers out there.

I've been utterly amazed in what has been accomplished by the BM Devs with their release of BM v1.0. No doubt, many of you share the same sentiment along with several million others around the world who have downloaded it. Of course, the BM mod is not perfect.  That's to be expected for a mod as big in scale and scope as BM is. Many persons have created and released mods to correct specific errors, while others have released larger add-on materials affecting the gameplay, look and sound of the game. We're all grateful that these individuals have done so. I've downloaded and installed many of them and they do improve the quality of BM. This endeavor is my way to give back to the BM community for taking so much from it.

To that end, I've initiated a project that focuses on finding and correcting the numerous dialog/subtitle errors that presently exist in BM. There are dozens of instances where the dialog that is spoken by the character in audio form is not accurately reflected in the subtitle that is displayed at the bottom of the screen in written form.

What Does This Mod Fix?
====================
I discovered the first error at the main BM reception desk at the beginning of the game, following the tram ride. Here you find Barney having problems with his computer. There's a scientist standing behind him, questioning Barney's capabilties in fixing his computer.

Scientist says - "Gordon, go and do what you were hired to do."
Barney retorts - "Shouldn't you be doing the same."

Barney's comment is not reflected at all as a subtitle, it's entirely missing and is not displayed. I was amazed that such an obvious mistake existed, at the very beginning of the game, yet. After all, BM was 8 years in the making. A little further on into the game, I came across another ommision. From that point forward, I started paying particular attention to what was being said and what was being shown as the subtitle. To my surprise, I discovered numerous similar errors which prompted me to begin the process of investigating how one could effect corrections to the applicable game files. 

Other corrections revolve around missed words or phrases, grammatical errors or just plain errors. I discovered one yesterday where the word "got" was displayed instead of "go". Yes, some of these errors are minor, nevertheless if there's a means for them to be corrected, they should be. BM will be better for it and we'll enjoy the game even more so.

The Process
==========
It begins by comparing the written text contained in the "closecaption_english.txt" file to the corresponding audio clip found in the appropriate sound folder. Once corrections are made to the "closecaption_english.txt" file, the "closecaption_english.dat" file needs to be updated with the corrections as well. This is accomplished by using the "closecaptioncompiler.exe" tool. This process automatically updates and overwrites the existing "closecaption_english.dat" file. It's a very painstaking process, but one that I feel needs to be done.

The Reason
=========
I'm just doing my little part in honing, polishing and improving BM to be as bug-free as it can possibly be. 

More importantly, this project is especially beneficial to those individuals that are hearing impaired. In some circumstances, subtiltles are the only means by which they can understand what's transpiring in the game, assists them in determining the tasks that need to be accomplished in order to progress the game further, and helps them in more fully understanding and appreciating the gameplay and storyline.

Installation
=========
PRIOR to doing anything, BACKUP your existing "closecaption_english.txt" and "closecaption_english.dat" files, located in your "resource" folder. This folder is usually found here:  Your game install drive letter/Steam/SteamApps/sourcemods/BMS/resource.
Once you've backed up these two original files, unzip the two files in the zip archive you just downloaded, into your "resource" folder.

Of course, you must enable the "Subtitles" option in the BM "Main Menu" under the "Audio" tab, then under the "Captioning" options. This mod encompases and is applicable to English subtitles only.

I'm not sure if the mod will be in effect using a gamesave file. At worst, it should be enabled at the next map load or next chapter start.  

Uninstallation
===========
Delete the two files you installed into your "resource" folder and re-insert your backup copies of the original files.

Going Forward
============
I'll endeavor to keep searching for additional errors and correct them as they are discovered, but this is a daunting task. After installing this mod, if you discover any additional errors, please report them here in this BM forum. Please provide me with as much info as possible so that I can easily zero in on the corrections that need to be applied. Typically, I require the game level/chapter, the character speaking (Barney, scientist, other) and as much of the spoken audio dialog as you can take note of. Once a sufficient number of new corrections are made, I'll release an updated version of the mod.

Thank you in advance for your invaluable contributions to this project.

Happy gaming everyone!
Dadster

